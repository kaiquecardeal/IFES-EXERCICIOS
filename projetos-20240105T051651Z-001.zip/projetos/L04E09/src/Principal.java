public class Principal {
	public static void main(String[] args) {
		int num = 10;
		int soma = 0;
		while(num>=3) {
			soma += num;
			num--;
		}	
		InOut.MsgDeInforma��o("", "soma = "+soma);
	}
}
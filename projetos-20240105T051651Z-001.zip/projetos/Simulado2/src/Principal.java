/*
Simulado
2
 */
public class Principal {
	public static void main(String[] args) {
		final int maxDado = 6; //representando um dado de seis lados
		int d1 = (int)(Math.random()*maxDado+1);
		int d2 = (int)(Math.random()*maxDado+1);
		int d3 = (int)(Math.random()*maxDado+1);
		String menu = "Dado 1 = "+d1;
		menu += "\nDado 2 = "+d2;
		menu += "\nDado 3 = "+d3;
		menu += "\n\nDigite a op��o desejada:";
		menu += "\n1) Informe se h� valores repetidos";
		menu += "\n2) Some e exiba um valor informado pelo usu�rio com o maior n�mero das 3 jogadas";
		menu += "\n3) Informe qual o valor do meio (maior que o menor e menor que o maior)";
		menu += "\n4) Exiba a m�dia dos valores elevada a um valor informado pelo usu�rio";
		menu += "\n5) Exiba as 3 jogadas como no exemplo abaixo";
		menu += "\n0) Sair do programa";
		int op = InOut.leInt(menu);
		
		if(op == 1) {
			if(d1 == d2 || d1==d3 || d2==d3) {
				InOut.MsgDeInforma��o("","H� valores repitidos!");
			}else {
				InOut.MsgDeInforma��o("","N�o h� valores repitidos!");
			}
		}else if(op == 2) {
			int maior = d1;
			if (d2>d3 && d2>d1) {
				maior = d2;
			}else if(d3>d2 && d3>d1) {
				maior = d3;
			}
			int valor = InOut.leInt("Informe um valor");
			InOut.MsgDeInforma��o("",maior+" + "+valor+" = "+(valor+maior));
		}else if(op == 3) {
			int meio = 0;
			if(d1>=d2 && d1<=d3) {
				meio = d1;
			}else if(d1<=d2 && d1>=d3) {
				meio = d1;
			}else if(d2<=d1 && d2>=d3) {
				meio = d2;
			}else if(d2>=d1 && d2<=d3) {
				meio = d2;
			}else if(d3<=d2 && d3>=d1) {
				meio = d3;
			}else if(d3>=d1 && d3<=d2) {
				meio = d3;
			}
			InOut.MsgDeInforma��o("","O valor do meio � o "+meio);
			//segunda resolu��o
			int maior = d1;
			if (d2>d3 && d2>d1) {
				maior = d2;
			}else if(d3>d2 && d3>d1) {
				maior = d3;
			}
			int menor = d1;
			if (d2<d3 && d2<d1) {
				maior = d2;
			}else if(d3<d2 && d3<d1) {
				maior = d3;
			}
			meio = d1+d2+d3-maior-menor;
			//terceira resolu��o
			if((d1>=d2 && d1<=d3)||(d1<=d2 && d1>=d3)) {
				meio = d1;
			}else if((d2<=d1 && d2>=d3)||(d2>=d1 && d2<=d3)) {
				meio = d2;
			}else {
				meio = d3;
			}
		}else if(op == 4) {
			int valor = InOut.leInt("Informe um valor");
			double media = (double)(d1+d2+d3)/3;
			double potencia = Math.pow(media,valor);
			InOut.MsgDeInforma��o("","O valor da pot�ncia � de "+potencia);
		}else if(op == 5) {
			String saida = "Dado 1 = "+d1;
			saida += "\nDado 2 = "+d2;
			saida += "\nDado 3 = "+d3;
			InOut.MsgDeInforma��o("",saida);
		}else if(op == 0) {
			InOut.MsgDeInforma��o("","Programa Encerrado!");
		}else {
			InOut.MsgDeInforma��o("","Op��o Inv�lida!");
		}
	}
}

public class Principal {
	public static void main(String[] args) {
		final int anoFuturo = 2025;
		int anoNascimento = InOut.leInt("Informe o seu ano de nascimento");
		int anoAtual = InOut.leInt("Informe o ano atual");
		int idade = anoAtual-anoNascimento;
		int idadeFutura = anoFuturo-anoNascimento;
		String saida = "Sua idade atual � de "+idade+" anos";
		saida = saida + "\nEm "+anoFuturo+ " voc� ter� "+idadeFutura+" anos";
		InOut.MsgDeInforma��o("",saida);
	}
}

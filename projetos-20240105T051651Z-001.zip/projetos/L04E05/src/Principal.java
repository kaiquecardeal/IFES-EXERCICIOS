public class Principal {
	public static void main(String[] args) {
		String str1, str2;
		int cont = 0;
		str1 = InOut.leString("Informe um caracter");
		do {			
			str2 = InOut.leString("Qual  foi o caracter digitado anteriormente?");
			cont++;
			if(!str1.equalsIgnoreCase(str2)) {
				InOut.MsgDeInforma��o("","Voc� errou!\nTente novamente!");
			}
		}while(!str1.equalsIgnoreCase(str2));
		InOut.MsgDeInforma��o("","Voc� acertou com "+cont+" tentativas!");
	}
}
public class Principal {
	public static void main(String[] args) {
		int j1, j2, j3;
		boolean cond = false;
		do {
			//////////////////////////////////////////////jogada do jogador 1
			do {
				j1 = InOut.leInt("Jogador 1, Informe 0 ou 1");
				if(j1!=0 && j1!=1) {
					InOut.MsgDeInforma��o("", "Jogador 1, valor inv�lido... informe novamente!");
				}
			}while(j1!=0 && j1!=1);
			//////////////////////////////////////////////jogada do jogador 2
			do {
				j2 = InOut.leInt("Jogador 2, Informe 0 ou 1");
				if(j2!=0 && j2!=1) {
					InOut.MsgDeInforma��o("", "Jogador 2, valor inv�lido... informe novamente!");
				}
			}while(j2!=0 && j2!=1);
			//////////////////////////////////////////////jogada do jogador 3
			do {
				j3 = InOut.leInt("Jogador 3, Informe 0 ou 1");
				if(j3!=0 && j3!=1) {
					InOut.MsgDeInforma��o("", "Jogador 3, valor inv�lido... informe novamente!");
				}
			}while(j3!=0 && j3!=1);
			//////////////////////////////////////////////resolu��o
			if(j1==j2 && j2==j3) {
				InOut.MsgDeInforma��o("", "Empate!");
			}else if(j1==j2 && j2!=j3) {
				InOut.MsgDeInforma��o("", "O jogador 3 ganhou!");
				cond = true;
			}else if(j1==j3 && j2!=j3) {
				InOut.MsgDeInforma��o("", "O jogador 2 ganhou!");
				cond = true;
			}else {
				InOut.MsgDeInforma��o("", "O jogador 1 ganhou!");
				cond = true;
			}			
		}while(!cond);		
	}
}

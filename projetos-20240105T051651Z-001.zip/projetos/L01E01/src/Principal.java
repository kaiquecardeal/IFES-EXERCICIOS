public class Principal {
	public static void main(String[] args) {
		double salBase;
		final double gratificacao = 0.05;
		final double imposto = 0.07;
		double salLiquido;
	
		salBase = InOut.leDouble("Informe o valor do sal�rio base");		
		salLiquido = salBase * gratificacao + salBase;
		salLiquido = salLiquido - salLiquido * imposto;
		InOut.MsgDeInforma��o("","O sal�rio liquido � de R$"+salLiquido);
		
	}
}

/*
Simulado
3
 */
public class Principal {
	public static void main(String[] args) {
		String menu = "Escolha de qual pa�s vai importar:";
		menu += "\n1 - USA";
		menu += "\n2 - Fran�a";
		menu += "\n3 - M�xico";
		menu += "\n4 - China";
		menu += "\n0 - Finalizar o programa";
		int op = InOut.leInt(menu);
		double total = 0;
		final double frete1 = 60;
		double valor;
		
		if(op == 1) {
			valor = InOut.leDouble("Informe o valor");
			total += valor+frete1;
			total *= 1.0576;
			InOut.MsgDeInforma��o("","Valor total R$"+total);
		}else if(op == 2) {
			valor = InOut.leDouble("Informe o valor");
			total += valor+75.5;
			total *= 1.0413;
			InOut.MsgDeInforma��o("","Valor total R$"+total);
		}else if(op == 3) {
			valor = InOut.leDouble("Informe o valor");
			total += valor+50;
			total *= 1.0808;
			InOut.MsgDeInforma��o("","Valor total R$"+total);
		}else if(op == 4) {
			valor = InOut.leDouble("Informe o valor");
			total += valor+80;
			total *= 1.071;
			InOut.MsgDeInforma��o("","Valor total R$"+total);
		}else if(op == 0) {
			InOut.MsgDeInforma��o("","Programa Encerrado!");
		}else {
			InOut.MsgDeInforma��o("","Op��o Inv�lida!");
		}
	}
}

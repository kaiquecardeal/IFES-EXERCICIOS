public class Principal {
	public static void main(String[] args) {
		int num = 0;
		String saida = "0, ";
		
		do {
			num+=2;
			if(num<50) {
				saida += num+", ";
			}else {
				saida += num+".";
			}			
		}while(num<50 && num>0);
		InOut.MsgDeInforma��o("", saida);
	}
}

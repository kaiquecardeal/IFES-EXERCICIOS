public class Principal {
	public static void main(String[] args) {
		double salBase = InOut.leDouble("Informe o valor do sal�rio base");
		int hExtra = InOut.leInt("Informe o n�mero de horas extras trabalhadas no m�s");
		int faltas = InOut.leInt("Informe o n�mero de faltas no m�s");
		double salLiquido = salBase + hExtra*(salBase/88);
		salLiquido -= faltas*(salBase/22);
		salLiquido *= 1.06; 
		salLiquido -= salBase*0.08;
		InOut.MsgDeInforma��o("","O sal�rio liquido � de R$"+salLiquido);		
	}
}

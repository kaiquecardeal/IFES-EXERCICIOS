public class Principal {
	public static void main(String[] args) {		
		String menu = "Digite:";
		menu += "\nA - Informar um novo valor.";
		menu += "\nB - Informa os n�meros m�ltiplos do valor informado";
		menu += "\nC - Informa se o n�mero informado � primo";
		menu += "\nD - Sair do programa";
		int op, cont;
		int num = InOut.leInt("Informe um valor");
		do {
			op = InOut.leChar(menu);
			switch(op) {
			case 'A':
				num = InOut.leInt("Informe um valor");
				if(num<0) {
					num *=-1;
				}
				break;
			case 'B':
				if(num<0) {
					num*=-1;
				}
				cont = (num/2)*-1;
				String saida = "-"+num+", ";
				while(cont<=num/2){
					if(cont!=0) {
						if(num%cont==0){
							saida += cont+", ";
						}
					}			
					cont++;
				}
				saida += num+".";
				InOut.MsgDeInforma��o("", saida);
				break;
			case 'C':
				String saida2 = "";
				if(num<0) {
					num*=-1;
					saida2 = "-";
				}
				cont = 1;
				int contP = 1;
				while(cont<=num/2){
					if(num%cont==0){
						contP++;
					}
					cont++;
				}
				if(contP>2) {
					saida2 += num+" n�o � primo";
				}else {
					saida2 += num+" � primo";
				}
				InOut.MsgDeInforma��o("",saida2);
				break;
			case 'D':
				InOut.MsgDeInforma��o("","Programa encerrado!");
				break;			
			default:
				InOut.MsgDeInforma��o("","Op��o inv�lida!");
				break;
			}
		}while(op!='D');
	}
}

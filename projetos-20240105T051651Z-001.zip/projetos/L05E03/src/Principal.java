public class Principal {
	public static void main(String[] args) {
		String menu = "Informe:";
		menu += "\n1 � Ler Valores";
		menu += "\n2 � Obter troco";
		menu += "\n3 � Mostrar c�dulas do troco";
		menu += "\n0 � Sair do programa";
		int op,vf=0,vt=0,troco=0;
		int c100=0,c50=0,c20=0,c10=0,c5=0,c2=0,c1=0;
		do {
			op = InOut.leInt(menu);
			switch(op) {
			case 1:
				vt = InOut.leInt("Informe o valor total da conta");
				vf = InOut.leInt("Informe o valor fornecido no pagamento");
				break;
			case 2:
				troco = vf-vt;
				InOut.MsgDeInforma��o("","O troco � de R$"+troco);
				break;
			case 3:
				int contaTroco = troco;
				while(contaTroco>0) {
					if(contaTroco>=100) {
						c100++;
						contaTroco-=100;
					}else if(contaTroco>=50) {
						c50++;
						contaTroco-=50;
					}else if(contaTroco>=20) {
						c20++;
						contaTroco-=20;
					}else if(contaTroco>=10) {
						c10++;
						contaTroco-=10;
					}else if(contaTroco>=5) {
						c5++;
						contaTroco-=5;
					}else if(contaTroco>=2) {
						c2++;
						contaTroco-=2;
					}else if(contaTroco>=1) {
						c1++;
						contaTroco-=1;
					}
				}
				String saida = "";
				if(c100>0) {
					saida = "C�dulas de 100: "+c100;
				}
				if(c50>0) {
					saida += "\nC�dulas de 50: "+c50;
				}
				if(c20>0) {
					saida += "\nC�dulas de 20: "+c20;
				}
				if(c10>0) {
					saida += "\nC�dulas de 10: "+c10;
				}
				if(c5>0) {
					saida += "\nC�dulas de 5: "+c5;
				}
				if(c2>0) {
					saida += "\nC�dulas de 2: "+c2;
				}
				if(c1>0) {
					saida += "\nC�dulas de 1: "+c1;
				}
				InOut.MsgDeInforma��o("", saida);
				break;				
			case 0:
				InOut.MsgDeInforma��o("","Programa encerrado!");
				break;
			default:
				InOut.MsgDeInforma��o("","Op��o Inv�lida!");
				break;
			}
		}while(op!=0);

	}
}
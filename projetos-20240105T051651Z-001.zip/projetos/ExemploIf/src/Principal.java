/* 
 * dado a soma de 3 valores informados pelo usu�rio informe se 
 * este resultado � maior, menor ou igual a zero.
 * 
 * 
 * */




public class Principal {
	public static void main(String[] args) {
		int n1 = InOut.leInt("Informe o 1� valor");
		int n2 = InOut.leInt("Informe o 2� valor");
		int n3 = InOut.leInt("Informe o 3� valor");
		int soma = n1+n2+n3;
		
		if(soma<0) {
			InOut.MsgDeInforma��o("", "o somat�rio � negativo");
		}else if(soma==0) {
			InOut.MsgDeInforma��o("", "o somat�rio deu zero");
		}else {
			InOut.MsgDeInforma��o("", "o somat�rio � positivo");
		}		
		
	}
}

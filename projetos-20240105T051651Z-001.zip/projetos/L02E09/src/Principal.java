public class Principal {
	public static void main(String[] args) {
		String menu = "Digite a op��o desejada:";
		menu += "\n1 - Soma";
		menu += "\n2 - Raiz Quadrada";
		menu += "\n0 - Sair do Programa";
		int op = InOut.leInt(menu);
		
		if(op == 1) {
			int n1 = InOut.leInt("Informe o 1� valor");
			int n2 = InOut.leInt("Informe o 2� valor");
			int resp = n1+n2;
			InOut.MsgDeInforma��o("", "A soma vale "+resp);
		}else if(op == 2) {
			int n = InOut.leInt("Informe o valor para raiz");
			double resp = Math.sqrt(n);
			InOut.MsgDeInforma��o("", "A raiz de "+n+" vale "+resp);
		}else if(op == 0) {
			InOut.MsgDeInforma��o("","Programa Encerrado!");
		}else {
			InOut.MsgDeInforma��o("","Op��o Inv�lida!");
		}
	}
}

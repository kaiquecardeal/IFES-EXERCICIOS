public class Principal {
	public static void main(String[] args) {
		int par = 0;
		String saida = "";
		
		while(par<5000) {
			par+=2;
			saida += par+", ";			
		}
		InOut.MsgDeInforma��o("", saida);
	}
}

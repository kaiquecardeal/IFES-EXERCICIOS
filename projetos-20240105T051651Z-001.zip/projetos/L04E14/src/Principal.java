public class Principal {
	public static void main(String[] args) {
		int n1 = 1;
		int n2 = 10;
		int n3 = 2;
		int n4 = 1;
		int n5 = 100;
		String saida = "";
		
		do {
			saida += n1+", ";
			n1++;
			saida += n2+", ";
			n2 += 10;
			saida += n3+", ";
			n3+=2;
			saida += n4+", ";
			n4+=2;
			saida += n5+"\n ";
			n5--;
		}while(n1<100);
		InOut.MsgDeInforma��o("",saida);
	}
}
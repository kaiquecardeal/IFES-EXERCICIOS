public class Principal {
	public static void main(String[] args) {
		int n1 = InOut.leInt("Informe o 1� valor");
		int n2 = InOut.leInt("Informe o 2� valor");
		int n3 = InOut.leInt("Informe o 3� valor");
		int n4 = InOut.leInt("Informe o 4� valor");
		String saida;
		int soma = 0;
		int cont = 0;
		
		if(n1>=n2 && n1>=n3 && n1>=n4) {
			saida = "Maior valor: "+n1;
		}else if(n2>=n1 && n2>=n3 && n2>=n4) {
			saida = "Maior valor: "+n2;
		}else if(n3>=n1 && n3>=n2 && n3>=n4) {
			saida = "Maior valor: "+n3;
		}else{
			saida = "Maior valor: "+n4;
		}		
		if(n1>=0) {
			cont++;
			soma = n1;
		}
		if(n2>=0) {
			cont++;
			soma += n2;
		}
		if(n3>=0) {
			cont++;
			soma += n3;
		}
		if(n4>=0) {
			cont++;
			soma += n4;
		}
		double media = (double)soma/cont;
		saida += "\nM�dia: "+media;
		saida += "\ncont: "+cont;
		saida += "\nsomatorio: "+soma;
		InOut.MsgDeInforma��o("",saida);
	}
}


public class Principal {
	public static void main(String[] args) {
		String login = InOut.leString("Informe o login");
		if(login.equalsIgnoreCase("ana")) {
			int senha = InOut.leInt("informe a senha");
			if(senha == 5214) {
				InOut.MsgDeInforma��o("","Acesso autorizado!");
			}else {
				InOut.MsgDeInforma��o("","Voc� digitou a senha errada!");
			}
		}else if(login.equalsIgnoreCase("sergio")) {
			int senha = InOut.leInt("informe a senha");
			if(senha == 2158) {
				InOut.MsgDeInforma��o("","Acesso autorizado!");
			}else {
				InOut.MsgDeInforma��o("","Voc� digitou a senha errada!");
			}
		}else if(login.equalsIgnoreCase("calixto")) {
			int senha = InOut.leInt("informe a senha");
			if(senha == 1024) {
				InOut.MsgDeInforma��o("","Acesso autorizado!");
			}else {
				InOut.MsgDeInforma��o("","Voc� digitou a senha errada!");
			}
		}else {
			InOut.MsgDeInforma��o("","Acesso n�o autorizado!");
		}
	}
}

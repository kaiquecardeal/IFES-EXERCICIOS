public class Principal {
	public static void main(String[] args) {
		int num,r1,r2,r3,r4,resto = 1,cont = 0;
		char op;
		String menu;
		
		do {
			num = (int)(Math.random()*46+45);
			r1 = (int)(Math.random()*45+1);
			r2 = (int)(Math.random()*45+1);
			r3 = (int)(Math.random()*45+1);
			r4 = (int)(Math.random()*45+1);
			menu = "Qual dos valores abaixo � m�ltiplo de "+num+"?";
			menu += "\nA - "+r1;
			menu += "\nB - "+r2;
			menu += "\nC - "+r3;
			menu += "\nD - "+r4;
			menu += "\nE - Nenhuma das anteriores";
			op = InOut.leChar(menu);
			cont++;
			switch(op) {
			case 'A':
				resto = num%r1;
				break;
			case 'B':
				resto = num%r2;
				break;
			case 'C':
				resto = num%r3;
				break;
			case 'D':
				resto = num%r4;
				break;
			case 'E':
				if(num%r1!=0 && num%r2!=0 && num%r3!=0 && num%r4!=0) {
					resto = 0;
				}
				break;
			default:
				InOut.MsgDeInforma��o("","Op��o inv�lida!");
				break;
			}
			if(resto!=0) {
				InOut.MsgDeInforma��o("","Voc� errou!\nTende outra vez...");
			}
		}while(resto!=0);
		InOut.MsgDeInforma��o("","Voc� acertou com "+cont+" tentativas!");
	}
}

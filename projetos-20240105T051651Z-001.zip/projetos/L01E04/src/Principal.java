public class Principal {
	public static void main(String[] args) {
		int A = InOut.leInt("Informe o valor de A");
		int B = InOut.leInt("Informe o valor de B");
		int C = InOut.leInt("Informe o valor de C");
		String saida = "Antes\nA = "+A+"\nB = "+B+"\nC = "+C;
		int aux = A;
		A = C;
		C = B;
		B = aux;	
		saida += "\n\nDepois\nA = "+A+"\nB = "+B+"\nC = "+C;
		InOut.MsgDeInforma��o("",saida);
	}
}

public class Principal {
	public static void main(String[] args) {
		double n1 = InOut.leDouble("informe o primeiro valor");
		double n2= InOut.leDouble("informe o segundo valor");
		if(n1+n2<20 || n1+n2>50) {
			if(n1>n2) {
				InOut.MsgDeInforma��o("", "fora do intervalor, maior n�mero "+n1);
			}else {
				InOut.MsgDeInforma��o("", "fora do intervalor, maior n�mero "+n2);
			}
		}else {
			if(n1>n2) {
				InOut.MsgDeInforma��o("", "dentro do intervalor, menor n�mero "+n2);
			}else {
				InOut.MsgDeInforma��o("", "dentro do intervalor, menor n�mero "+n1);
			}
		}
	}
}


// fa�a o usuario irformar 2 valores, o programa deve retornar
// a soma deles caso esta soma seja menor do que 20 ou maior do
// que 50 caso contr�rio retorne a sua multiplica��o.


public class Principal {
	public static void main(String[] args) {
		InOut.MsgDeInforma��o("Programa 01", "Este � o meu primeiro programa!");
	
	}
}

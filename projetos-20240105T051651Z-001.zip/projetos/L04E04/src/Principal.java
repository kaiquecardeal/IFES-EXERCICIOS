public class Principal {
	public static void main(String[] args) {
		final int maxRand = 100;
		int n1, n2, soma;
		
		int cont=0;
		
		do {
			n1 = (int)(Math.random()*maxRand);
			n2 = (int)(Math.random()*maxRand);
			soma = n1+n2;
			cont++;
		}while(soma<=180 && n1!=n2);
		String saida = "N1 = "+n1;
		saida += "\nN2 = "+n2;
		saida += "\nSoma = "+soma;
		saida += "\nA contagem foi de : "+cont;
		InOut.MsgDeInforma��o("",saida);		
	}
}
public class Principal {
	public static void main(String[] args) {
		final int maxRand = 100;
		int n1, n2, soma,aux,op,valorResp=0;
		boolean cond = false;
		int r1=0,r2=0,r3=0,r4=0,r5=0;
		char resp;
		int cont = 1;
		String menu;
		do {
			n1 = (int)(Math.random()*maxRand);
			n2 = (int)(Math.random()*maxRand);
			soma = n1+n2;
			aux = (int)(Math.random()*3)+3;
			op = (int)(Math.random()*5)+1;			
			if(op==1) {
				r1 = soma;
				r2 = soma+aux+1;
				r3 = soma+aux+2;
				r4 = soma-aux+1;
				r5 = soma-aux+2;
			}else if(op==2) {
				r1 = soma+aux+1;
				r2 = soma;
				r3 = soma+aux+2;
				r4 = soma-aux+1;
				r5 = soma-aux+2;
			}else if(op==3) {
				r1 = soma+aux+1;
				r2 = soma+aux+2;
				r3 = soma;
				r4 = soma-aux+1;
				r5 = soma-aux+2;
			}else if(op==4) {
				r1 = soma+aux+1;
				r2 = soma-aux+1;
				r3 = soma+aux+2;
				r4 = soma;
				r5 = soma-aux+2;
			}else if(op==5) {
				r1 = soma+aux+1;
				r2 = soma-aux+2;
				r3 = soma+aux+2;
				r4 = soma-aux+1;
				r5 = soma;
			}
			menu = "Quanto vale "+n1+" + "+n2+"? (informar mai�sculo)";
			menu += "\nA - "+r1;
			menu += "\nB - "+r2;
			menu += "\nC - "+r3;
			menu += "\nD - "+r4;
			menu += "\nE - "+r5;
			resp = InOut.leChar(menu);
			switch(resp) {
			case 'A':
				valorResp = r1;
				break;
			case 'B':
				valorResp = r2;
				break;
			case 'C':
				valorResp = r3;
				break;
			case 'D':
				valorResp = r4;
				break;
			case 'E':
				valorResp = r5;
				break;
			default:
				InOut.MsgDeInforma��o("","Op��o Invalida!");
				break;
			}
			if(valorResp == soma) {
				InOut.MsgDeInforma��o("","Voc� acertou com "+cont+" tentativas!");
				cond = true;
			}else {
				cont++;
				InOut.MsgDeInforma��o("","Voc� errou animal... tente novamente!");
			}			
		}while(!cond);
	}
}
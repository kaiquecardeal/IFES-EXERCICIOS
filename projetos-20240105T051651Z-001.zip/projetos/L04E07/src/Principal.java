public class Principal {
	public static void main(String[] args) {
		final int mult = 3;
		int num = InOut.leInt("Informe um valor");
		String saida = num+"\n";
		
		while(num<=100) {
			num *= mult; // num = num * mult;
			saida += num+"\n";			
		}
		InOut.MsgDeInforma��o("",saida);
	}
}
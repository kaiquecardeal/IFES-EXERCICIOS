//simulado para a prova 1
/* 	eu sei fazer comet�rio de 
 	multiplas linhas
*/
public class Principal {
	public static void main(String[] args) {
		final int const1 = 7;
		final int const2 = 20;
		double resp;
		String menu = "Informe:";
		menu += "\n1) Calcule a raiz quadrada de sua m�dia";
		menu += "\n2) Subtraia um terceiro valor informado pelo usu�rio da soma dos dois valores";
		menu += "\n3) informe se o menor dos 2 valores � m�ltiplo de 7";
		menu += "\n4) informe se algum dos valores � maior que 20";
		menu += "\n5) Exiba em forma de express�o o maior subtra�do pelo menor dos dois valores";
		menu += "\n0) Sair do programa";
		
		int n1 = InOut.leInt("Informe o 1� valor");
		int n2 = InOut.leInt("Informe o 2� valor");	
		int op = InOut.leInt(menu);
		
		if(op == 1) {
			double media = (n1+n2)/2;
			double raiz  = Math.sqrt(media);
			InOut.MsgDeInforma��o("","A raiz de m�dia � "+raiz);
		}else if(op == 2) {
			double n3 = InOut.leDouble("Informe o terceiro valor");
			resp = (n1+n2)-n3;
			InOut.MsgDeInforma��o("","O resultado deu "+resp);			
		}else if(op == 3) {
			int menor;
			if(n1<n2) {
				menor = n1;
			}else {
				menor = n2;
			}
			int resto = menor%const1;
			if(resto == 0) {
				InOut.MsgDeInforma��o("","O menor valor � divisivel por "+const1);	
			}else {
				InOut.MsgDeInforma��o("","O menor valor n�o � divisivel por "+const1);	
			}
		}else if(op == 4) {
			if(n1>const2 || n2>const2) {
				InOut.MsgDeInforma��o("","H� valor(es) maior do que "+const2);	
			}else {
				InOut.MsgDeInforma��o("","N�o h� valor(es) maior do que "+const2);	
			}
		}else if(op == 5) {
			int maior;
			int menor;
			if(n1>n2) {
				maior = n1;
				menor = n2;
			}else {
				maior = n2;
				menor = n1;
			}
			String texto = maior+" - "+menor+" = "+(maior-menor);
			InOut.MsgDeInforma��o("", texto);
		}else if(op == 0) {
			InOut.MsgDeInforma��o("", "Programa Encerrado!");
		}else {
			InOut.MsgDeInforma��o("", "Op��o Inv�lida!");
		}
	}
}
public class Principal {
	public static void main(String[] args) {
		int idade = InOut.leInt("Informe a idade do atleta");
		
		if(idade<5) { //menor que 5
			InOut.MsgDeInforma��o("","Idade n�o permitida!");
		}else if(idade<=7) {//entre 5 e 7
			InOut.MsgDeInforma��o("","Infantil A ");
		}else if(idade<=10) {//entre 8 e 10
			InOut.MsgDeInforma��o("","Infantil B ");
		}else if(idade<=13) {//entre 11 e 13
			InOut.MsgDeInforma��o("","Juvenil A ");
		}else if(idade<=17) {//entre 14 e 17
			InOut.MsgDeInforma��o("","Juvenil B ");
		}else {//maior que 17
			InOut.MsgDeInforma��o("","S�nior");
		}
	}
}

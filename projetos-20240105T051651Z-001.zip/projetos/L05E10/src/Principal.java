public class Principal {
	public static void main(String[] args) {
		final double esc = 1, cai = 1.2, GE = 1.5, GG = 1.9, ano = 0.01, n1 = 0, n2 = 0.1, n3 = 0.15; 
		double salFinal=0, salBase = InOut.leDouble("Informe o sal�rio base");
		char op;
		int nivel;
		int tempoServico;
		
		String menu = "A � Escritur�rio\n" + 
				"B � Caixa\n" + 
				"C � Gerente de Expediente\n" + 
				"D � Gerente Geral\n";
		do {
			op = InOut.leChar(menu);
			switch(op) {
			case 'A':
				salFinal = salBase *esc;
				tempoServico = InOut.leInt("Informe o tempo de servi�o");
				salFinal += tempoServico*ano*salBase;
				break;
			case 'B':
				salFinal = salBase *cai;
				tempoServico = InOut.leInt("Informe o tempo de servi�o");
				salFinal += tempoServico*ano*salBase;
				break;
			case 'C':
				salFinal = salBase *GE;
				tempoServico = InOut.leInt("Informe o tempo de servi�o");
				salFinal += tempoServico*ano*salBase;
				do {
					nivel = InOut.leInt("Informe o n�vel da ag�ncia");
					switch(nivel) {
					case 1:
						salFinal += n1*salBase;
						break;
					case 2:
						salFinal += n2*salBase;
						break;
					case 3:
						salFinal += n3*salBase;
						break;
					default:
						InOut.MsgDeInforma��o("","Op��o Inv�lida!");
						break;
					}
				}while(nivel<1||nivel>3);
				break;	
			case 'D':
				salFinal = salBase *GG;
				tempoServico = InOut.leInt("Informe o tempo de servi�o");
				salFinal += tempoServico*ano*salBase;
				do {
					nivel = InOut.leInt("Informe o n�vel da ag�ncia");
					switch(nivel) {
					case 1:
						salFinal += n1*salBase;
						break;
					case 2:
						salFinal += n2*salBase;
						break;
					case 3:
						salFinal += n3*salBase;
						break;
					default:
						InOut.MsgDeInforma��o("","Op��o Inv�lida!");
						break;
					}
				}while(nivel<1||nivel>3);
				break;	
			default:
				InOut.MsgDeInforma��o("","Op��o Inv�lida!");
				break;
			}
		}while(op!='A' && op!='B' && op!='C' && op!='D');	
		InOut.MsgDeInforma��o("","O sal�rio final e de R$ "+salFinal);
	}
}
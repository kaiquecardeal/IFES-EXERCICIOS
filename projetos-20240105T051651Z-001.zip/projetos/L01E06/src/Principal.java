public class Principal {
	public static void main(String[] args) {
		int hora = InOut.leInt("Informe a hora atual");
		int dia = InOut.leInt("Informe o dia atual");
		int mes = InOut.leInt("Informe o mes atual");
		int ano = InOut.leInt("Informe ano atual");
		int horasTotais = hora;
		horasTotais += (dia-1)*24;
		horasTotais += (mes-1)*30*24;
		horasTotais += (ano-1)*12*30*24;
		InOut.MsgDeInforma��o("","Se passaram "+horasTotais+" horas apos o nascimento de Cristo");
	}
}

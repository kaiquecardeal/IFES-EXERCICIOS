public class Principal {
	public static void main(String[] args) {
		String p1,p2,p3,p4,p5,p6,p7;
		int pontos = 0;
		p1 = InOut.leString("1 - N�o reclama se ela demorar mais de 1 hora para se arrumar? (sim/n�o)");
		p2 = InOut.leString("2 - Diz que ela esta linda depois de produzida? (sim/n�o)");
		if(p1.equalsIgnoreCase("sim") && p2.equalsIgnoreCase("sim")) {
			pontos+=5;
		}else if(p1.equalsIgnoreCase("n�o") && p2.equalsIgnoreCase("n�o")) {
			pontos-=10;
		}
		p3 = InOut.leString("3 - Fica ao lado dela a festa inteira? (sim/n�o)");
		if(p3.equalsIgnoreCase("n�o")) {
			p4 = InOut.leString("Vai beber ao lado dos amigos? (sim/n�o)");
			if(p4.equalsIgnoreCase("sim")) {
				pontos-=5;
				p5 = InOut.leString("Entre voc� e seus l� bebendo tem mulher chamada Fernandinha? (sim/n�o)");
				if(p5.equalsIgnoreCase("sim")) {
					pontos-=10;
					p6 = InOut.leString("Fernandinha loira e magra? (sim/n�o)");
					if(p6.equalsIgnoreCase("sim")) {
						pontos-=30;
					}
					p7 = InOut.leString("Fernandinha te cumprimenta com 3 beijinhos dizendo �Ahhh que saudade!!!� (sim/n�o)");
					if(p7.equalsIgnoreCase("sim")) {
						pontos-=150;
					}
				}
			}
		}
		InOut.MsgDeInforma��o("", "Voc� obteve "+pontos+" pontos durante a festa com a sua esposa!");
	}
}
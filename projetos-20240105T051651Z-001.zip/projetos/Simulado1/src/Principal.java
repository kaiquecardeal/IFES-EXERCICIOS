public class Principal {
	public static void main(String[] args) {
		int num = (int)(Math.random()*6+1);
		InOut.MsgDeInforma��o("","num = "+num);
		
		
		
	}
}
public class Principal {
	public static void main(String[] args) {
		String login = InOut.leString("Informe o login");
		if(login.equalsIgnoreCase("ana") || login.equalsIgnoreCase("Sergio") || login.equalsIgnoreCase("Calixto")) {
			int senha = InOut.leInt("Informe a senha");
			if(login.equalsIgnoreCase("ana") && senha == 5214) {
				InOut.MsgDeInforma��o("","Acesso autorizado!");
			}else if(login.equalsIgnoreCase("sergio") && senha == 2158) {
				InOut.MsgDeInforma��o("","Acesso autorizado!");
			}else if(login.equalsIgnoreCase("calixto") && senha == 1024) {
				InOut.MsgDeInforma��o("","Acesso autorizado!");
			}else {
				InOut.MsgDeInforma��o("","Voc� digitou a senha errada!");
			}			
		}else {
			InOut.MsgDeInforma��o("","Acesso n�o autorizado!");
		}
	}
}

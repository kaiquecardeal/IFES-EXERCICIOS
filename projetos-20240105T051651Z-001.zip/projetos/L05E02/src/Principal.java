public class Principal {
	public static void main(String[] args) {
		double V, V0, a, t;
		String menu = "Digite:";
		menu += "\n1 - Para achar a velocidade final";
		menu += "\n2 - Para achar a velocidade inicial";
		menu += "\n3 - Para achar a acelera��o";
		menu += "\n4 - Para achar o tempo";
		menu += "\n0 - Encerrar o programa";
		int op;
		
		do {
			op = InOut.leInt(menu);
			switch(op) {
			case 1:
				V0 = InOut.leDouble("Informe a valocidade inicial (m/s)");
				a = InOut.leDouble("Informe a acelera��o (m/s�)");
				t = InOut.leDouble("Informe o tempo (s)");
				V = V0+a*t;
				InOut.MsgDeInforma��o("", "A velocidade final � de "+V+"m/s");
				break;
			case 2:
				V = InOut.leDouble("Informe a valocidade final (m/s)");
				a = InOut.leDouble("Informe a acelera��o (m/s�)");
				t = InOut.leDouble("Informe o tempo (s)");
				V0 = V-a*t;
				InOut.MsgDeInforma��o("", "A velocidade inicial � de "+V0+"m/s");
				break;
			case 3:
				V = InOut.leDouble("Informe a valocidade final (m/s)");
				V0 = InOut.leDouble("Informe a valocidade inicial (m/s)");
				t = InOut.leDouble("Informe o tempo (s)");
				a = (V-V0)/t;
				InOut.MsgDeInforma��o("", "A acelera��o � de "+a+"m/s�");
				break;
			case 4:
				V = InOut.leDouble("Informe a valocidade final (m/s)");
				V0 = InOut.leDouble("Informe a valocidade inicial (m/s)");
				a = InOut.leDouble("Informe a acelera��o (m/s�)");
				t = (V-V0)/a;
				InOut.MsgDeInforma��o("", "O tempo � de "+t+"s");
				break;
			case 0:				
				InOut.MsgDeInforma��o("", "Programa Encerrado!");
				break;
			default:
				InOut.MsgDeInforma��o("","Op��o Inv�lida!");
				break;
			}
		}while(op!=0);
	}
}
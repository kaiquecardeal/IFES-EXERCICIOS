public class Principal {
	public static void main(String[] args) {
		int A = InOut.leInt("Informe o valor de A");
		int B = InOut.leInt("Informe o valor de B");
		int C = InOut.leInt("Informe o valor de C");
		
		int delta = (int)(Math.pow(B,2)-4*A*C);
		double X1 = (-B+Math.sqrt(delta))/(2*A);
		double X2 = (-B-Math.sqrt(delta))/(2*A);
		String saida = "X' = "+X1+"\nX\" = "+X2;
		InOut.MsgDeInforma��o("",saida);
	}
}

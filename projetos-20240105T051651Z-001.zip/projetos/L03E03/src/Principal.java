public class Principal {
	public static void main(String[] args) {
		double nota1 = InOut.leDouble("Informe o valor da 1� nota");
		double nota2 = InOut.leDouble("Informe o valor da 2� nota");
		double media = (nota1+nota2)/2;
		if(media>=60) {
			int aulasM = InOut.leInt("Informe o n�mero de aulas ministradas");
			int presenca = InOut.leInt("Informe o n�mero de aulas assistidas");
			double frequencia = (100*presenca)/aulasM;
			if(frequencia>=75) {
				InOut.MsgDeInforma��o("","Parab�ns voc� esta aprovado!");
			}else {
				InOut.MsgDeInforma��o("","Reprovado por falta... seu vagabundo!!!");
			}	
		}else {
			InOut.MsgDeInforma��o("","Reprovado por nota!");
		}
	}
}

public class Principal {
	public static void main(String[] args) {
		int n1 = InOut.leInt("Informe o 1� valor");
		int n2 = InOut.leInt("Informe o 2� valor");
		int n3 = InOut.leInt("Informe o 3� valor");
		int n4 = InOut.leInt("Informe o 4� valor");
		
		if(n1<=n2 && n1<=n3 && n1<=n4){
			InOut.MsgDeInforma��o("", n1+" � o menor valor!");
		}else if(n2<=n1 && n2<=n3 && n2<=n4){
			InOut.MsgDeInforma��o("", n2+" � o menor valor!");
		}else if(n3<=n1 && n3<=n2 && n3<=n4){
			InOut.MsgDeInforma��o("", n3+" � o menor valor!");
		}else {
			InOut.MsgDeInforma��o("", n4+" � o menor valor!");
		}
	}
}

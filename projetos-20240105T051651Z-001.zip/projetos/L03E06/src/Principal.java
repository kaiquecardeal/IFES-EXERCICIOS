public class Principal {
	public static void main(String[] args) {
		double n1 = InOut.leDouble("Informe o valor do 1� n�mero");
		double n2 = InOut.leDouble("Informe o valor do 2� n�mero");
		double n3 = InOut.leDouble("Informe o valor do 3� n�mero");
		double resp;

		if(n1>=0) {
			resp = Math.sqrt(n1);
			InOut.MsgDeInforma��o("","A raiz quadrada de "+n1+" � "+resp);
		}else {
			resp = Math.pow(n1,2);
			InOut.MsgDeInforma��o("","O quadrado de "+n1+" � "+resp);
		}
		if(n2>=10 && n2<=100) {
			InOut.MsgDeInforma��o("","N�mero est� entre 10 e 100 � intervalo permitido");
		}
		if(n3<n2) {
			resp = n2-n3;
			InOut.MsgDeInforma��o("",n2+" - "+n3+" = "+resp);
		}else {
			InOut.MsgDeInforma��o("",n3+" + 1 = "+(n3+1));
		}
	}
}

